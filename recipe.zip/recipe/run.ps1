cd client/
npm i
npm run build
cd ../server/
npm i
node server.js