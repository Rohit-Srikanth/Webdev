module.exports = {
  secret: "ermwhathesigma",
  geminiAPIKEY: "",
};
